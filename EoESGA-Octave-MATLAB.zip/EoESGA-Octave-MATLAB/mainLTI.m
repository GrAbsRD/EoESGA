
clc; clear;

t0 = 0;
t1 = 10;
xi = pi / 8;
v_angular0 = 2 * pi;

q0 = [1; 0; 0; 0];
omega = @(t)[pi*sin(pi/8); -pi/3*cos(pi/8); -2*sin(pi/3)];

m = 10;
Tau = [0.8, 0.6, 0.4, 0.2, 1e-1, 1e-2, 1e-3];
%Tau = [0.8, 0.6, 0.4, 0.2, 1e-1, 1e-2, 1e-3, 1e-4, 1e-5];
Emax = zeros(m, length(Tau));

%% For differ tau
for j = 1:length(Tau)
    tau = Tau(j);

    %% AS
    n = floor((t1 - t0) / tau);
    q = zeros(4, n);
    q(:, 1) = q0;
    for i=1:n - 1
        omega_k = omega(t0 + i * tau);
        A_k = [         0, -omega_k(1), -omega_k(2), -omega_k(3);
               omega_k(1),           0,  omega_k(3), -omega_k(2);
               omega_k(2), -omega_k(3),           0,  omega_k(1);
               omega_k(3),  omega_k(2), -omega_k(1),          0];
        G_AS_K = eye(size(A_k)) * cos(norm(omega_k)*tau/2) +...
                 A_k / norm(omega_k) * sin(norm(omega_k)*tau/2);
        q(:, i + 1) = G_AS_K * q(:, i);
    end

    %% NS
    for l = 1:m
        Q = EoEsga4QkdeLTI(l, tau, omega(1), q0, t0, t1);
        Err = zeros(n, 1);
        for i = 1:n
            Err(i) = norm(Q(:, i) - q(:, i), 2);
        end
        Emax(l, j) = max(Err);
    end

end

for j = 1:length(Tau)
    semilogy(1:m, Emax(:, j));
    hold on;
end



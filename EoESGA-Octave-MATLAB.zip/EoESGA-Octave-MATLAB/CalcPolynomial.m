function T = CalcPolynomial(c, x)

    T = c(end);
    len = length(c);
    for i = 1:len - 1
        T = T * x + c(len - i);
    end

end


function G = SpTranMat4QkdeLTV(l, tau, v_angular)

    U = [           0, -v_angular(1), -v_angular(2), -v_angular(3);
         v_angular(1),             0,  v_angular(3), -v_angular(2);
         v_angular(2), -v_angular(3),             0,  v_angular(1);
         v_angular(3),  v_angular(2), -v_angular(1),             0];

    c = tau^2 * norm(v_angular, 2)^2 / 4;
    beta = AFSIAGenBeta(l, c);
    alpha = c * beta^2;
    I = eye(size(U));
    G = ((1-alpha)*I + tau*beta*U) / (1+alpha);

end


function q = EulerAng2Quat(yaw_angle, pitch_angle, roll_angle)

    yaw_angle = yaw_angle / 2;
    pitch_angle = pitch_angle / 2;
    roll_angle = roll_angle / 2;

    q = [0; 0; 0; 0];
    q(1) = cos(yaw_angle)*cos(pitch_angle)*cos(roll_angle) +...
           sin(yaw_angle)*sin(pitch_angle)*sin(roll_angle);
    q(2) = cos(yaw_angle)*cos(pitch_angle)*sin(roll_angle) -...
           sin(yaw_angle)*sin(pitch_angle)*cos(roll_angle);
    q(3) = cos(yaw_angle)*sin(pitch_angle)*cos(roll_angle) +...
           sin(yaw_angle)*cos(pitch_angle)*sin(roll_angle);
    q(4) =-cos(yaw_angle)*sin(pitch_angle)*sin(roll_angle) +...
           sin(yaw_angle)*cos(pitch_angle)*cos(roll_angle);

end

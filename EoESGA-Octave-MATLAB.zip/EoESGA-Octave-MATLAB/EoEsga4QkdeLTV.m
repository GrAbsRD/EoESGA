function q = EoEsga4QkdeLTV(l, tau, omega, state_q0, t0, t1)

    n = floor((t1 - t0) / tau);
    q = zeros(4, n);
    t = t0;
    q(:, 1) = state_q0;
    for i = 1:n - 1
        t = t + tau;
        v_angular = feval(omega, t);
        G = SpTranMat4QkdeLTV(l, tau, v_angular);
        q(:, i + 1) = G * q(:, i);
    end

end


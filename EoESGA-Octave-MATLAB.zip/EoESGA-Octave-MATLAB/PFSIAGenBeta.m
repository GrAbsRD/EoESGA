function beta = PFSIAGenBeta(l, c)

    s = [floor((l - 1) / 2); floor(l / 2)];

    a = zeros(s(1) + 1, 1);
    b = zeros(s(2) + 1, 1);
    f_eta = @(l, k)(l-k) / ((2*l-k) * (k+1));

    a(1) = 0.5;
    for j = 1:s(1)
        a(j + 1) = a(j) * f_eta(l, 2*j-1) * f_eta(l, 2*j);
    end

    b(1) = 1;
    for j = 1:s(2)
        b(j + 1) = b(j) * f_eta(l, 2*j-2) * f_eta(l, 2*j-1);
    end

    n = CalcPolynomial(a, -c);
    d = CalcPolynomial(b, -c);
    beta = n / d;

end


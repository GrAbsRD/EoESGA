
clc; clear;

t0 = 0;
t1 = 10;
xi = pi / 8;
v_angular0 = 2 * pi;

q0 = [cos(xi/2); 0; sin(xi/2); 0];
omega = @(t)[-v_angular0*(1-cos(xi));
             -v_angular0*sin(xi)*sin(v_angular0*t);
             v_angular0*sin(xi)*cos(v_angular0*t)];

m = 10;
Tau = [0.8, 0.6, 0.4, 0.2, 1e-1, 1e-2, 1e-3, 1e-4, 1e-5];
Emax = zeros(m, length(Tau));

%% For differ tau
for j = 1:length(Tau)
    tau = Tau(j);

    %% AS
    n = floor((t1 - t0) / tau);
    q = zeros(4, n);
    qAS = @(t)[cos(xi/2); 0;...
               sin(xi/2)*cos(v_angular0*t);
               sin(xi/2)*sin(v_angular0*t)];
    q(:, 1) = q0;
    for i=1:n - 1
        omega_k = omega(t0 + i * tau);
        A_k = [         0, -omega_k(1), -omega_k(2), -omega_k(3);
               omega_k(1),           0,  omega_k(3), -omega_k(2);
               omega_k(2), -omega_k(3),           0,  omega_k(1);
               omega_k(3),  omega_k(2), -omega_k(1),          0];
        G_AS_K = eye(size(A_k)) * cos(norm(omega_k)*tau/2) +...
                 A_k / norm(omega_k) * sin(norm(omega_k)*tau/2);
        q(:, i + 1) = G_AS_K * q(:, i);
    end

    %% NS
    for l = 1:m
        Q = EoEsga4QkdeLTV(l, tau, omega, q0, t0, t1);
        Err = zeros(n, 1);
        for i = 1:n
            Err(i) = norm(Q(:, i) - q(:, i), 2);
        end
        Emax(l, j) = max(Err);
    end

end

for j = 1:length(Tau)
    semilogy(1:m, Emax(:, j));
    hold on;
end



function a = SkewMat2Vec(W)

    a = zeros(3, 1);
    a(1) = W(3, 2);
    a(2) = W(1, 3);
    a(3) = W(2, 1);

end

